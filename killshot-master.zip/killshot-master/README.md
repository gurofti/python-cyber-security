 # KILLSHOT  
A Penetration Testing Framework, Information gathering tool & Website Vulnerability Scanner

**Why KillShot** ?

You Can use this tool to Spider your website and get important information and gather information automaticaly using 
whatweb-host-traceroute-dig-fierce-wafw00f or to Identify the cms and to find the vulnerability in your website using 
Cms Exploit Scanner && WebApp Vul Scanner Also You can use killshot to Scan automaticly multiple type of scan with nmap and unicorn . And With this tool You can Generate PHP Simple Backdoors upload it manual and connect to the target using killshot

This Tool Bearing A simple Ruby Fuzzer Tested on VULSERV.exe And Linux Log clear script To change the content of login paths
 Spider can help you to find parametre of the site and scan xss and sql 
 
 ![killshot-logo_v1](https://user-images.githubusercontent.com/19738278/47605704-7eaab180-d9f9-11e8-97cc-74fad3dc152c.png)
 
 
 
 
   # Menu
    {0} Spider 
    {1} Web technologie 
    {2} WebApp Vul Scanner
    {3} Port Scanner
    {4} CMS Scanner
    {5} Fuzzers 
    {6} Cms Exploit Scanner
    {7} Backdoor Generation
    {8} Linux Log Clear
     
# WebApp Vul Scanner
    {1} Xss scanner
    {2} Sql Scanner
    {3} Tomcat RCE

# Port Scanner
     [0] Nmap Scan
     [1] Unicorn Scan
    Nmap Scan 
     [2] Nmap Os Scan 
     [3] Nmap TCP Scan
     [4] Nmap UDB Scan 
     [5] Nmap All scan
     [6] Nmap Http Option Scan 
     [7] Nmap Live target In Network
    Unicorn Scan
    [8] Services OS 
    [9] TCP SYN Scan on a whole network 
    [01] UDP scan on the whole network
      
# Backdoor Generation 
     {1} Generate Shell
     {2} Connect Shell
     
# USAGE 
    1 ----- Help Command 
    [site]  MAKE YOUR TARGET
    [help] show this MESSAGE
    [exit] show this MESSAGE
    2 ------ Site command 
    Put your target www.example.com
    without the http
    
    
    
# Linux Setup 

    git clone https://github.com/bahaabdelwahed/killshot
    cd killshot
    ruby setup.rb (if setup show any error just try to install the gems/tool manual )
    ruby killshot.rb
   
https://www.youtube.com/watch?v=SEGRh86J6vk

Use KillShot To Detect and Scan cms vulnrability  (Joomla && Wordpress) And Scan For Xss And Sql

https://www.youtube.com/watch?v=QPF-rppYSOY
