#/usr/bin/ruby -w 

puts "Gems Instalation "
system("gem install colorize && gem install nokogiri")
puts "Tools Instalation"
system("sudo apt-get install nmap && sudo apt-get install whatweb && sudo apt-get install host && sudo apt-get install -y dnsutils
 && sudo apt-get install wafw00f")
